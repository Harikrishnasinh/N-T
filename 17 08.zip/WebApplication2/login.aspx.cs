﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Response.Write("hey !!!");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
          
        }

        protected void Button3_Click1(object sender, EventArgs e)
        {
            Response.Write(password.Value);
            Response.Write(email.Value);
            string sql = "select Count(*) from register_data where email= '" + email.Value + "' and password = '" + password.Value + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, db.con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            Response.Write(dt.Rows[0][0]);
            if(dt.Rows.Count > 0)
            {
                Response.Write("ok");
            }
            else
            {
                Response.Write("not ok");
            }
        }
    }
}