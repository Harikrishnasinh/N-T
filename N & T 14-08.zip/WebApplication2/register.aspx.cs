﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace WebApplication2
{
    public partial class register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Write("harlaksdjf");
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            Response.Write("harlaksdjf");
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
                Response.Write("harlaksdjf");
                Response.Write(username.Value);
                Response.Write(password.Value);
                Response.Write(email.Value);
            string sql = "insert into register_data (username , email , password) values ('"+username.Value+ "','"+email.Value+"','"+password.Value+"')";
                SqlDataAdapter da = new SqlDataAdapter(sql, db.con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                Response.Write(sql);
            //Response.Write(dt.Rows[0][0].ToString());
            //Response.Write(dt.Rows[0][1].ToString());
            //Response.Write(dt.Rows[0][2].ToString());
        }
    }
}