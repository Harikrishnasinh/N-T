﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_email"] == null)
            {
                Response.Redirect("login.aspx");
            }
            else
            {
            //Response.Write("hey");
            string sql = "select * from register_data where email= '" + Session["user_email"]+ "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, db.con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            //Response.Write(dt.Rows[0][0]);
            username_left.InnerText = dt.Rows[0][1].ToString();
            }
        }
    }
}