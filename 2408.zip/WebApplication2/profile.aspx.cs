﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class profile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_email"] == null)
            {
                Response.Redirect("login.aspx");
            }
            else
            {
                string sql = "select * from register_data where email= '" + Session["user_email"] + "'";
                SqlDataAdapter da = new SqlDataAdapter(sql, db.con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                profile_username.Value = dt.Rows[0][1].ToString();
                profile_email.Value = dt.Rows[0][2].ToString();
            }
        }
    }
}