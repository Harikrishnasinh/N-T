﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class userprofile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["username"] == null)
            {
                Response.Redirect("login.aspx");
            }
            else
            {
                string user = Request.QueryString["username"];
                string sql = "select * from register_data where username ='" + user + "'";
                SqlDataAdapter da = new SqlDataAdapter(sql, db.con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                username_profile.InnerText = dt.Rows[0][1].ToString();
                fullname_profile.InnerText = dt.Rows[0][3].ToString();
                thoughts_count();
            }
        }
        public void thoughts_count()
        {
            string user = Request.QueryString["username"];
            string sql = "select * from data where thought_by ='" + user + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, db.con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            Response.Write(dt.Rows[0][0].ToString());
            Repeater1.DataSource = dt;
            Repeater1.DataBind();
            thought_count_number();
        }
        public void thought_count_number()
        {
            string user = Request.QueryString["username"];
            string sql = "select count(*) from data where thought_by ='" + user + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, db.con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            thought_count.InnerText = dt.Rows[0][0].ToString();
        }
    }
}
