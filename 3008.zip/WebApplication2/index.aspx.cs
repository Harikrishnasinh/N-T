﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_email"] == null)
            {
                Response.Redirect("login.aspx");
            }

            else
            {
                fetchData();
                //Response.Write("hey");
                string sql1 = "select * from register_data where email= '" + Session["user_email"]+ "'";
                SqlDataAdapter da1 = new SqlDataAdapter(sql1, db.con);
                DataTable dt1 = new DataTable();
                da1.Fill(dt1);
                //Response.Write(dt.Rows[0][0]);
                user_id.Value = dt1.Rows[0][1].ToString();
                //thought_username.InnerText = dt.Rows[0][1].ToString();
                username_left.InnerText = dt1.Rows[0][1].ToString();
                getdata();
            }
        }

        protected void addButton_Click(object sender, EventArgs e)
        {
            
            var dateTime = DateTime.Now;
            var longDateValue = dateTime.ToLongDateString();
            if (addtext.Value != "")
            {
                Random random = new Random();

                //string sql = "insert into data (thought,thought_by,time) values('" + addtext.Value + "','" + user_id.Value + "','" + longDateValue.ToString() + "')";
                string sql = "insert into data (thought , thought_by, time) values ('" + addtext.Value + "','" + user_id.Value + "','" + longDateValue.ToString()+ "')";
                //Response.Write(sql);
                SqlDataAdapter da = new SqlDataAdapter(sql, db.con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                addtext.Value = "";
                
                //if(dt.Rows != null)
                //{
                  //  Response.Write("something went wrong");
                    fetchData();
                    getdata();
                //}
            }
            else
            {
                Response.Write("please enter something !!!");
            }
        }
        public void fetchData()
        {
            string sql = "select * from data order by id desc";
            SqlDataAdapter da = new SqlDataAdapter(sql, db.con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            Repeater1.DataSource = dt;
            Repeater1.DataBind();

            string sql1 = "select * from register_data";
            SqlDataAdapter da1 = new SqlDataAdapter(sql1, db.con);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);
            Repeater3.DataSource = dt1;
            Repeater3.DataBind();

            getdata();
            //Response.Write(dt.Rows[0][0]);
            //Response.Write("hello");
            //Response.Write(id_user.Value);
        }

        public void getText()
        {
          //  Response.Write("this is getText...");
            string sql = "select * from data where thought_by='" + user_id.Value + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, db.con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            Repeater2.DataSource = dt;
            Repeater2.DataBind();
        }

        public void getdata()
        {
            getText();
        }
    }
}