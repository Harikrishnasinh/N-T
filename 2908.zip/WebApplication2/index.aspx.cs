﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_email"] == null)
            {
                Response.Redirect("login.aspx");
            }
            else
            {
            fetchData();
            //Response.Write("hey");
            string sql = "select * from register_data where email= '" + Session["user_email"]+ "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, db.con);
            DataTable dt = new DataTable();
            da.Fill(dt);
                //Response.Write(dt.Rows[0][0]);
            user_id.Value = dt.Rows[0][1].ToString();
                //thought_username.InnerText = dt.Rows[0][1].ToString();
            username_left.InnerText = dt.Rows[0][1].ToString();
            }
        }

        protected void addButton_Click(object sender, EventArgs e)
        {
            
            var dateTime = DateTime.Now;
            var longDateValue = dateTime.ToLongDateString();
            string sql = "insert into data (thought,thought_by,time) values('"+addtext.Value+ "','" + user_id.Value +"','"+ longDateValue.ToString() + "')";
            Response.Write(sql);
            SqlDataAdapter da = new SqlDataAdapter(sql, db.con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows != null)
            {
                Session["message"] = "Thanks , let's meet soon !!!";
            }
            else
            {
                Response.Write("not ok");
            }
        }
        public void fetchData()
        {
            string sql = "select * from data";
            SqlDataAdapter da = new SqlDataAdapter(sql, db.con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            Repeater1.DataSource = dt;
            Repeater1.DataBind();
            //Response.Write(dt.Rows[0][0]);
            //Response.Write("hello");
            getDataOfUser();
            //Response.Write(id_user.Value);
        }

        public void getDataOfUser()
        {
            string sql = "select * from data where thought_by='"+ user_id.Value +"'";
            SqlDataAdapter da = new SqlDataAdapter(sql, db.con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            Repeater2.DataSource = dt;
            Repeater2.DataBind();
        }
    }
}